<dl>
    
    <?php foreach ($items as $key => $value): ?>
        
        <dt><?= $key ?></dt>
        <dd><?= $value ?></dd>
    
    <?php endforeach ?>

</dl>
