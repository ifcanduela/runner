# Runner

And online PHP code runner with support for Composer.

> Do not host this tool to the public. It is not sandboxed!

# Quickstart

1. Clone this repository and move into it.
2. Run `php serve`.
3. Open `localhost:8080`in the browser.
